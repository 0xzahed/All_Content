import tkinter as tk
import psutil
import os
from tkinter import ttk

class SystemSecurityFrame(tk.Frame):
    def __init__(self, parent):
        super().__init__(parent)
        self.create_widgets()

    def create_widgets(self):
        # Set background color of the frame
        self.configure(bg="#E0F7FA")  # Light Sky Blue background

        # Title Label
        title_label = tk.Label(self, text="System & Security", font=("Arial", 18, "bold"), fg="black", bg="#E0F7FA")
        title_label.pack(pady=20)

        # System Information frame
        system_info_frame = tk.Frame(self, bg="#E0F7FA")
        system_info_frame.pack(fill="x", padx=20, pady=10)

        # CPU Usage label with colors
        cpu_label = tk.Label(system_info_frame, text=f"CPU Usage: {psutil.cpu_percent()}%", font=("Arial", 12), fg="black", bg="#E0F7FA")
        cpu_label.pack(anchor="w", padx=10)

        # Memory Usage label with colors
        memory = psutil.virtual_memory()
        memory_label = tk.Label(system_info_frame, text=f"Memory Usage: {round(memory.percent, 2)}%", font=("Arial", 12), fg="black", bg="#E0F7FA")
        memory_label.pack(anchor="w", padx=10)

        # Disk Usage label with colors
        disk = psutil.disk_usage('/')
        disk_label = tk.Label(system_info_frame, text=f"Disk Usage: {round(disk.percent, 2)}%", font=("Arial", 12), fg="black", bg="#E0F7FA")
        disk_label.pack(anchor="w", padx=10)

        # Firewall status with dynamic color
        firewall_status = self.get_firewall_status()
        firewall_label = tk.Label(self, text=f"Firewall Status: {firewall_status}", font=("Arial", 12), fg="black", bg="#E0F7FA")
        firewall_label.pack(pady=10)

        # SSH Toggle Button with color customization
        ssh_button = tk.Button(self, text="Enable SSH", command=self.toggle_ssh, font=("Arial", 12, "bold"), bg="#388E3C", fg="white", relief="solid")
        ssh_button.pack(pady=5)

    def get_firewall_status(self):
        """ Example function to check firewall status (assuming UFW is installed) """
        try:
            result = os.popen('sudo ufw status').read()
            return "Active" if "Status: active" in result else "Inactive"
        except Exception as e:
            return "Error: " + str(e)

    def toggle_ssh(self):
        """ Function to enable or disable SSH """
        if os.system("systemctl is-active --quiet ssh"):
            os.system("sudo systemctl stop ssh")  # Disable SSH
            os.system("sudo systemctl disable ssh")
        else:
            os.system("sudo systemctl enable ssh")  # Enable SSH
            os.system("sudo systemctl start ssh")


class PyOSManagerApp:
    def __init__(self, root):
        self.root = root
        self.root.title("OS Manager")
        self.root.geometry("800x600")
        self.root.configure(bg="#ffffff")

        self.current_frame = None
        self.create_widgets()

    def create_widgets(self):
        # Title Label for the Control Panel
        title_label = tk.Label(self.root, text="Control Panel", font=("Arial", 24, "bold"), bg="#388E3C", fg="white")
        title_label.pack(pady=20)

        # Navigation Buttons with color
        button_frame = ttk.Frame(self.root)
        button_frame.pack(side="top", fill="x", pady=10)

        button_style = ttk.Style()
        button_style.configure("TButton", font=("Arial", 12), padding=6, relief="solid", background="#388E3C", foreground="white", width=15)
        button_style.map("TButton", background=[("active", "#1B5E20")])

        network_button = ttk.Button(button_frame, text="Network Settings", command=self.show_network_frame, style="TButton")
        network_button.grid(row=0, column=0, padx=5)

        sound_button = ttk.Button(button_frame, text="Sound Settings", command=self.show_sound_frame, style="TButton")
        sound_button.grid(row=0, column=1, padx=5)

        battery_button = ttk.Button(button_frame, text="Battery Status", command=self.show_battery_frame, style="TButton")
        battery_button.grid(row=0, column=2, padx=5)

        task_manager_button = ttk.Button(button_frame, text="Task Manager", command=self.show_task_manager_frame, style="TButton")
        task_manager_button.grid(row=0, column=3, padx=5)

        system_details_button = ttk.Button(button_frame, text="System Details", command=self.show_system_details_frame, style="TButton")
        system_details_button.grid(row=0, column=4, padx=5)

        system_security_button = ttk.Button(button_frame, text="System & Security", command=self.show_system_security_frame, style="TButton")
        system_security_button.grid(row=0, column=5, padx=5)

        # Content Frames
        self.network_frame = tk.Frame(self.root)
        self.sound_frame = tk.Frame(self.root)
        self.battery_frame = tk.Frame(self.root)
        self.task_manager_frame = tk.Frame(self.root)
        self.system_details_frame = tk.Frame(self.root)
        self.system_security_frame = SystemSecurityFrame(self.root)

        # Show the initial frame (e.g., Network Frame)
        self.show_network_frame()

    def show_frame(self, frame):
        if self.current_frame:
            self.current_frame.pack_forget()
        self.current_frame = frame
        self.current_frame.pack(expand=True, fill="both")

    def show_network_frame(self):
        self.show_frame(self.network_frame)

    def show_sound_frame(self):
        self.show_frame(self.sound_frame)

    def show_battery_frame(self):
        self.show_frame(self.battery_frame)

    def show_task_manager_frame(self):
        self.show_frame(self.task_manager_frame)

    def show_system_details_frame(self):
        self.show_frame(self.system_details_frame)

    def show_system_security_frame(self):
        self.show_frame(self.system_security_frame)


if __name__ == "__main__":
    root = tk.Tk()
    app = PyOSManagerApp(root)
    root.mainloop()
