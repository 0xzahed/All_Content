import tkinter as tk
import alsaaudio
import subprocess

class SoundFrame(tk.Frame):
    def __init__(self, parent):
        super().__init__(parent)
        self.mixer = alsaaudio.Mixer()
        self.create_widgets()

    def create_widgets(self):
        # Set a soft sky blue background for the entire frame
        self.configure(bg="#E1F5FE")  # Soft Sky Blue background

        # Volume Control Section with porcelain-like slider design
        volume_label = tk.Label(self, text="Volume:", font=("Arial", 14, "bold"), bg="#E1F5FE", fg="#1E3A8A")  # Dark blue text
        volume_label.pack(pady=10)

        self.volume_slider = tk.Scale(self, from_=0, to=100, orient=tk.HORIZONTAL, command=self.set_volume, 
                                      bg="#ECEFF1", fg="black", troughcolor="#B0BEC5", sliderlength=25, width=25)
        self.volume_slider.set(self.mixer.getvolume()[0])  # Set the initial volume
        self.volume_slider.pack(pady=15)

        # Brightness Control Section with porcelain-like slider design
        brightness_label = tk.Label(self, text="Brightness:", font=("Arial", 14, "bold"), bg="#E1F5FE", fg="#1E3A8A")  # Dark blue text
        brightness_label.pack(pady=10)

        self.brightness_slider = tk.Scale(self, from_=0, to=100, orient=tk.HORIZONTAL, command=self.set_brightness, 
                                          bg="#ECEFF1", fg="black", troughcolor="#B0BEC5", sliderlength=25, width=25)
        self.brightness_slider.set(self.get_brightness())
        self.brightness_slider.pack(pady=15)

        # Create a button to reset to default volume and brightness (for added functionality)
        reset_button = tk.Button(self, text="Reset to Default", command=self.reset_defaults, font=("Arial", 12, "bold"), bg="#4CAF50", fg="white", relief="solid")
        reset_button.pack(pady=20)

    def set_volume(self, vol):
        """ Set the system volume using alsaaudio """
        self.mixer.setvolume(int(vol))

    def set_brightness(self, brightness):
        """ Set the system brightness using xrandr (Linux) """
        brightness = int(brightness) / 100  # Convert to a float value between 0 and 1
        try:
            subprocess.run(["xrandr", "--output", "eDP-1", "--brightness", str(brightness)])
        except Exception as e:
            print(f"Failed to set brightness: {e}")

    def get_brightness(self):
        """ Get the current brightness level using xrandr (Linux) """
        try:
            result = subprocess.run(["xrandr", "--verbose"], capture_output=True, text=True)
            for line in result.stdout.splitlines():
                if "Brightness" in line:
                    return int(float(line.split(":")[1].strip()) * 100)  # Return as percentage
        except Exception as e:
            print(f"Failed to get brightness: {e}")
            return 50  # Default value if there's an error
        return 50  # Default value if no brightness is found

    def reset_defaults(self):
        """ Reset the volume and brightness to default values """
        self.volume_slider.set(50)
        self.brightness_slider.set(50)
        self.set_volume(50)  # Set volume to 50
        self.set_brightness(50)  # Set brightness to 50

# Example to test the GUI
if __name__ == "__main__":
    root = tk.Tk()
    app = SoundFrame(root)
    app.pack(padx=20, pady=20)
    root.mainloop()
