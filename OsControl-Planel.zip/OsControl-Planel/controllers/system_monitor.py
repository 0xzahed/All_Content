import tkinter as tk
import psutil

class TaskManagerFrame(tk.Frame):
    def __init__(self, parent):
        super().__init__(parent)
        self.create_widgets()
        self.update_status()

    def create_widgets(self):
        # Set a light background for the entire frame
        self.configure(bg="#E0F7FA")  # Light Sky Blue background

        # CPU Usage label with custom color
        self.cpu_label = tk.Label(self, text="CPU Usage: ", font=("Arial", 14), bg="#E0F7FA", fg="#01579B")  # Blue text, SkyBlue background
        self.cpu_label.pack(pady=10)

        # Memory Usage label with custom color
        self.memory_label = tk.Label(self, text="Memory Usage: ", font=("Arial", 14), bg="#E0F7FA", fg="#388E3C")  # Green text, SkyBlue background
        self.memory_label.pack(pady=10)

        # Add a Refresh button with a custom color
        refresh_button = tk.Button(self, text="Refresh", command=self.update_status, font=("Arial", 12, "bold"), bg="#388E3C", fg="white", relief="solid")
        refresh_button.pack(pady=20)

    def update_status(self):
        # Get current CPU usage and update the CPU label
        self.cpu_label.config(text=f"CPU Usage: {psutil.cpu_percent()}%")
        
        # Get current memory usage and update the memory label
        memory = psutil.virtual_memory()
        self.memory_label.config(text=f"Memory Usage: {memory.percent}%")
        
        # Update every 1 second (1000 ms)
        self.after(1000, self.update_status)  # Calls the update_status method again after 1 second

# Example to test the GUI
if __name__ == "__main__":
    root = tk.Tk()
    app = TaskManagerFrame(root)
    app.pack(padx=20, pady=20)
    root.mainloop()
